This module provides avalibility to allow user sign in with top Chinese Social 
Networks.

Currently we support:
Sina weibo （新浪微博）, Chinese twitter like website.
Tencent （QQ）, biggest Chinese IM provider.
Renren（人人网）, biggest Chinese facebook like website.
Kaixin001（开心网）, secondary Chinese facebook like website.

Configuration:
The module contians 1 main module and 4 sub-modules.
Each of these 4 sub-modules represent 4 Chinese Social Networks.
Install and enable main module and any of these sub-modules you desired.
Go to configuration page (/admin/config/csna) and fill the KEY and SECRET you 
get from these Chinese Social Networks.

URL of subscribing for KEYs and SECRETs:
Weibo http://open.weibo.com/
QQ http://connect.qq.com/
Renren http://dev.renren.com/website
Kaixin http://open.kaixin001.com/
